
const form = document.querySelector('form');
const input = document.querySelector('input[name="comment"]');
const commentContainer = document.querySelector('.comments');
const templateData = document.querySelector('#comment-template').content;
const commentCount = document.querySelector('#comment-count span');
const loadComment = document.querySelector('.load_comment__btn');
const fileUpload = document.querySelector('#file-upload');
const previewContainer = document.querySelector('.image-preview'); 
const likesCount = document.querySelector('.likes');
let selectedImage = null; 
let likedComment = 0;
let abortController = new AbortController();
let offset = 0;
const limit = 5;

function loadComments() {
    fetch(`http://localhost:3000/comments?limit=${limit}&offset=${offset}`)
      .then(response => response.json())
      .then(data => {
        console.log('data:', data); 
        // Если данных меньше лимита, можно скрыть кнопку загрузки
        if (data.length < limit) {
          document.querySelector('.load_comment__btn').style.display = 'none';
        }
        
        data.forEach(commentData => {
            console.log('commentData:', commentData);
            addComments(commentData.text, commentData.username, "./img/male-person-silhouette-strict-suit-side-view-shadow-back-lit-white-background.jpg", commentData.img, commentData.relativeTime);
        });
        countComments();
        
        // Увеличиваем offset на количество загруженных комментариев
        offset += data.length;
      })
      .catch(err => console.error('Ошибка загрузки комментариев:', err));
}

// Функция для получения комментариев с сервера
const fetchComments = () => {
    fetch('http://localhost:3000/comments')
        .then(response => response.json())
        .then(data => {
            commentContainer.innerHTML = '';
            data.forEach(comment => {
                addComments(comment.text, comment.username, "./img/male-person-silhouette-strict-suit-side-view-shadow-back-lit-white-background.jpg", comment.img, comment.relativeTime);
            });
            countComments();
        })
        .catch(err => console.error('Ошибка загрузки комментариев:', err));
};


const countComments = () => {
    commentCount.textContent = commentContainer.querySelectorAll('.comment').length;
};

const addComments = (text, username = 'Анонимус', avatar = "./img/male-person-silhouette-strict-suit-side-view-shadow-back-lit-white-background.jpg", img = null, time) => {
    const comment = templateData.cloneNode(true);
    const commentElement = comment.firstElementChild;
    commentElement.querySelector('.avatar').src = avatar;
    commentElement.querySelector('.username').textContent = username;
    commentElement.querySelector('.time').textContent = time;
    commentElement.querySelector('.comment-text').textContent = text;

    if (img) {
        const imgElement = document.createElement('img');
        imgElement.src = img;
        imgElement.alt = 'Картинка пользователя';
        imgElement.classList.add('comment-image');
        commentElement.querySelector('.comment-img').appendChild(imgElement);
    }

    commentContainer.prepend(commentElement);

};

// Обработка отправки формы
form.addEventListener('submit', function(e) {
    e.preventDefault(); 
    const commentText = input.value.trim();
    if (commentText) {
        const formData = new FormData;
        formData.append('username', 'Анонимус');
        formData.append('text', commentText);

        if(fileUpload.files[0]) {
            formData.append('image', fileUpload.files[0]);
        }
    
        fetch('http://localhost:3000/comments', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(result => {
            // Можно добавить комментарий в DOM на основе ответа сервера
            addComments(result.text, result.username, "./img/male-person-silhouette-strict-suit-side-view-shadow-back-lit-white-background.jpg", result.img);
            input.value = '';
            selectedImage = null;
            fileUpload.value = '';
            previewContainer.innerHTML = '';
            countComments();
            showComments();
        })
        .catch(err => console.error('Ошибка при добавлении комментария:', err));
    }
});


const fileUploadHandler = (event) => {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function (e) {
            selectedImage = e.target.result; 
            previewContainer.innerHTML = '';

            const imgPreview = document.createElement('img');
            imgPreview.src = selectedImage;
            imgPreview.alt = 'Предпросмотр изображения';
            imgPreview.classList.add('preview-image');

            const removeImgPreview = document.createElement('button');
            removeImgPreview.textContent = 'Удалить';
            removeImgPreview.classList.add('remove-btn');

            removeImgPreview.addEventListener('click', () => {
                selectedImage = null;
                fileUpload.value = '';
                previewContainer.innerHTML = '';
                // Создаём новый AbortController и вешаем обработчик заново
                abortController = new AbortController();
                fileUpload.addEventListener('change', fileUploadHandler, { signal: abortController.signal });
            });

            previewContainer.appendChild(imgPreview);
            previewContainer.appendChild(removeImgPreview);
            // После загрузки файла отменяем обработчик
            abortController.abort();
        };
        reader.readAsDataURL(file);
    }
};

fileUpload.addEventListener('change', fileUploadHandler, { signal: abortController.signal });

loadComment.addEventListener('click', (e) => {
    e.preventDefault();
    loadComments();
})


loadComments();


fetchComments();